import { Controller, Get, Post, Put, Delete, Body, Param } from '@nestjs/common';
import { ItemsService } from './items.service';

@Controller('items')
export class ItemsController {
  constructor(private readonly itemsService: ItemsService) {}

  @Post()
  create(@Body() body: { name: string; description: string }) {
    return this.itemsService.create(body.name, body.description);
  }

  @Get()
  findAll() {
    return this.itemsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.itemsService.findOne(Number(id));
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() body: { name: string; description: string }) {
    return this.itemsService.update(Number(id), body.name, body.description);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    this.itemsService.remove(Number(id));
  }
}
